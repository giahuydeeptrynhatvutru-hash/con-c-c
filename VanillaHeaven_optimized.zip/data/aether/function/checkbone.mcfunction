
execute if block ~ ~ ~ carved_pumpkin if block ~ ~-1 ~ bone_block run summon pig ~ ~-1 ~ {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}
execute if block ~ ~ ~ carved_pumpkin if block ~ ~-1 ~ bone_block run playsound minecraft:block.bone_block.place ambient @a[distance=0..5] ~ ~ ~ 1 1.8
execute if block ~ ~ ~ carved_pumpkin if block ~ ~-1 ~ bone_block run playsound minecraft:block.bone_block.place ambient @a[distance=0..5] ~ ~ ~ 1 2
execute if block ~ ~ ~ carved_pumpkin if block ~ ~-1 ~ bone_block run playsound minecraft:block.bone_block.place ambient @a[distance=0..5] ~ ~ ~ 1 1.7
execute if block ~ ~ ~ carved_pumpkin if block ~ ~-1 ~ bone_block run particle block{block_state:{Name:bone_block}} ~ ~ ~ .1 .2 .1 1 200
execute as @e[tag=portalcheck,type=minecraft:item_frame,distance=0..3] run function aether:createportal
