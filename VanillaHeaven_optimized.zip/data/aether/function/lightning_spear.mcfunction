execute as @s unless entity @s[scores={attacktime=700..}] run scoreboard players add @s attacktime 1

execute as @s[scores={attacktime=700..}] run title @s actionbar [{text:"⚡ ⚡ ⚡ ⚡ ⚡ ⚡ ⚡",bold:true,color:"yellow"},{text:"",bold:true,color:"black"}]
execute as @s[scores={attacktime=600..699}] run title @s actionbar [{text:"⚡ ⚡ ⚡ ⚡ ⚡ ⚡",bold:true,color:"yellow"},{text:" ⚡",bold:true,color:"black"}]
execute as @s[scores={attacktime=500..599}] run title @s actionbar [{text:"⚡ ⚡ ⚡ ⚡ ⚡",bold:true,color:"yellow"},{text:" ⚡ ⚡",bold:true,color:"black"}]
execute as @s[scores={attacktime=400..499}] run title @s actionbar [{text:"⚡ ⚡ ⚡ ⚡",bold:true,color:"yellow"},{text:" ⚡ ⚡ ⚡",bold:true,color:"black"}]
execute as @s[scores={attacktime=300..399}] run title @s actionbar [{text:"⚡ ⚡ ⚡",bold:true,color:"yellow"},{text:" ⚡ ⚡ ⚡ ⚡",bold:true,color:"black"}]
execute as @s[scores={attacktime=200..299}] run title @s actionbar [{text:"⚡ ⚡",bold:true,color:"yellow"},{text:" ⚡ ⚡ ⚡ ⚡ ⚡",bold:true,color:"black"}]
execute as @s[scores={attacktime=100..199}] run title @s actionbar [{text:"⚡",bold:true,color:"yellow"},{text:" ⚡ ⚡ ⚡ ⚡ ⚡ ⚡",bold:true,color:"black"}]
execute as @s[scores={attacktime=0..99}] run title @s actionbar [{text:"",bold:true,color:"yellow"},{text:"⚡ ⚡ ⚡ ⚡ ⚡ ⚡ ⚡",bold:true,color:"black"}]


effect give @s minecraft:speed 1 1 true
execute as @s[scores={attacktime=100..,rclick=1..}] at @s run summon marker ~ ~ ~ {Tags:["lightning","player"]}
execute as @s[scores={attacktime=100..,rclick=1..}] at @s run scoreboard players remove @s attacktime 100

execute at @s unless entity @s[tag=big] run summon minecraft:armor_stand ~ ~1 ~ {Invisible:true,Invulnerable:true,ShowArms:true,DisabledSlots:4144959,Pose:{RightArm:[268f,85f,177f]},equipment:{mainhand:{id:"golden_spear",Count:1}},Tags:["spear"]}
execute at @s unless entity @s[tag=big] run clear @s *[minecraft:custom_data={false:1b}]