execute as @s at @s if dimension minecraft:overworld run tag @s add overworld
# [FIX] Thoát sớm nếu overworld
execute as @s[tag=overworld] run return 0

execute as @s at @s if dimension aether:the_aether if predicate aether:50p run tag @s add die

execute as @s[tag=!die] at @s if dimension aether:the_aether run place template aether:village ~-6 ~-12 ~-6
execute as @s[tag=!die] at @s if dimension aether:the_aether run summon pig ~2 ~1 ~-2 {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}
execute as @s[tag=!die] at @s if dimension aether:the_aether run summon pig ~-2 ~1 ~3 {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}
execute as @s[tag=!die] at @s if dimension aether:the_aether run summon pig ~ ~1 ~5 {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}
execute as @s at @s if dimension aether:the_aether run tp @s ~ ~-100 ~
execute as @s at @s if dimension aether:the_aether run kill @s
