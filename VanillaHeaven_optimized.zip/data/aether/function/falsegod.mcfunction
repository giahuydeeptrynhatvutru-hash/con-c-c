tp @e[tag=falsegod,tag=!awake] ~ ~10000 ~
kill @e[tag=falsegod,tag=!awake]
team join Aether @s
execute as @s[tag=!summoned] at @s run tp @s ~ ~ ~ facing entity @p feet
execute as @s[tag=!summoned] at @s run tag @s add summoned

data merge entity @s {Fire:0b}

execute at @s[tag=!stage2start] if predicate aether:15p run execute as @a[distance=0.01..4] run damage @s 5 minecraft:mob_projectile by @e[tag=falsegod,limit=1,sort=nearest]

execute as @s[tag=stage2] at @s positioned ~ ~2 ~ run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..3.3] run playsound minecraft:item.shield.block ambient @a[distance=0..15] ~ ~ ~ 1 1.8
execute as @s[tag=stage2] at @s positioned ~ ~2 ~ run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..3.3] run data modify entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..3.3,limit=1,sort=nearest] Motion set value 0
execute as @s[tag=stage2] at @s positioned ~ ~2 ~ run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..3.3] run tag @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..3.3] add stopped

bossbar set minecraft:false players @a[distance=0..50]
execute store result score @s bosshealth run data get entity @s Health
scoreboard players remove @s bosshealth 100
execute store result bossbar minecraft:false value run scoreboard players get @s bosshealth

effect give @s minecraft:slow_falling infinite 1 true

execute at @s[tag=stage2] unless entity @a[distance=0..40] run effect give @s minecraft:resistance 1 100 true
execute unless entity @s[scores={attacktime=1..}] run execute store result score @s attacktype run random value 1..4
execute unless entity @s[scores={attacktime=1..}] run scoreboard players set @s attacktime 200
scoreboard players remove @s[scores={attacktime=1..}] attacktime 1

execute if entity @s[scores={attacktime=1..,attacktype=1,bosshealth=1..},tag=!stage2start,tag=stage2] at @s unless entity @e[tag=cloud,distance=0..1] if predicate aether:1p run summon marker ^ ^1 ^1 {Tags:["cloud"]}
execute if entity @s[scores={attacktime=1..,attacktype=4,bosshealth=1..},tag=!stage2start,tag=stage2] at @s unless entity @e[tag=lightning,distance=0..1] if predicate aether:5p run summon marker ^ ^1 ^1 {Tags:["lightning"]}
execute if entity @s[scores={attacktime=1..,attacktype=1,bosshealth=1..},tag=!stage2start] at @s unless entity @e[tag=cloud,distance=0..1] if predicate aether:1p run summon marker ^ ^1 ^1 {Tags:["cloud"]}
execute if entity @s[scores={attacktime=1..,attacktype=4,bosshealth=1..},tag=!stage2start] at @s unless entity @e[tag=lightning,distance=0..1] if predicate aether:5p run summon marker ^ ^1 ^1 {Tags:["lightning"]}
execute if entity @s[scores={attacktime=2..,attacktype=2..3,bosshealth=1..},tag=!stage2start] at @s unless entity @e[type=breeze,distance=0..9] if predicate aether:1p run summon breeze ~ ~ ~ {Tags:["false"]}
execute if entity @s[scores={attacktime=1..1,attacktype=2,bosshealth=1..},tag=!stage2start] as @e[type=breeze,tag=false] at @s run summon lightning_bolt ~ ~ ~
execute if entity @s[scores={attacktime=1..1,attacktype=2,bosshealth=1..},tag=!stage2start] as @e[type=breeze,tag=false] run kill @s


execute if entity @s[scores={attacktime=1..,attacktype=3,bosshealth=1..},tag=!stage2start] at @s unless entity @e[type=breeze,distance=0..9] if predicate aether:1p positioned 12 253 0 if block ~ ~ ~ minecraft:soul_fire run summon marker ~ ~ ~ {Tags:["heal"]}
execute if entity @s[scores={attacktime=1..,attacktype=3,bosshealth=1..},tag=!stage2start] at @s unless entity @e[type=breeze,distance=0..9] if predicate aether:1p positioned -12 253 0 if block ~ ~ ~ minecraft:soul_fire run summon marker ~ ~ ~ {Tags:["heal"]}
execute if entity @s[scores={attacktime=1..,attacktype=3,bosshealth=1..},tag=!stage2start] at @s unless entity @e[type=breeze,distance=0..9] if predicate aether:1p positioned 0 253 12 if block ~ ~ ~ minecraft:soul_fire run summon marker ~ ~ ~ {Tags:["heal"]}
execute if entity @s[scores={attacktime=1..,attacktype=3,bosshealth=1..},tag=!stage2start] at @s unless entity @e[type=breeze,distance=0..9] if predicate aether:1p positioned 0 253 -12 if block ~ ~ ~ minecraft:soul_fire run summon marker ~ ~ ~ {Tags:["heal"]}

execute as @s[tag=summoned,scores={bosshealth=300..},tag=!stage2start] at @s unless block ~ ~-7 ~ #aether:non_solid_air if block ~ ~2.2 ~ #aether:non_solid_air if block ~ ~.1 ~ #aether:non_solid_air run tp @s ~ ~.1 ~ facing entity @p feet
execute as @s[tag=summoned,scores={bosshealth=1..},tag=!stage2start,tag=!stage2] at @s run particle cloud ~ ~ ~ .9 0 .9 0 20 force
execute as @s[tag=summoned,scores={bosshealth=1..},tag=!stage2start,tag=stage2] at @s run particle minecraft:dust{color:[.6,.6,.6],scale:2} ~ ~ ~ .9 0 .9 0 20 force
execute as @s[tag=summoned,scores={bosshealth=200..299},tag=!stage2start] at @s unless block ~ ~-6 ~ #aether:non_solid_air if block ~ ~2.2 ~ #aether:non_solid_air if block ~ ~.1 ~ #aether:non_solid_air run tp @s ~ ~.1 ~ facing entity @p feet
execute as @s[tag=summoned,scores={bosshealth=200..299},tag=!stage2start] at @s run particle minecraft:dust{color:[1,1,1],scale:2} ~ ~ ~ .9 0 .9 0 20 force

execute as @s[tag=summoned,scores={bosshealth=100..199},tag=!stage2start] at @s unless block ~ ~-5 ~ #aether:non_solid_air if block ~ ~2.2 ~ #aether:non_solid_air if block ~ ~.1 ~ #aether:non_solid_air run tp @s ~ ~.1 ~ facing entity @p feet
execute as @s[tag=summoned,scores={bosshealth=1..199},tag=!stage2start] at @s run particle minecraft:dust{color:[.6,.6,.6],scale:2} ~ ~ ~ .9 0 .9 0 20 force

execute as @s[tag=summoned,scores={bosshealth=1..},tag=!stage2start] at @s unless block ~ ~-4 ~ #aether:non_solid_air if block ~ ~2.2 ~ #aether:non_solid_air if block ~ ~.1 ~ #aether:non_solid_air run tp @s ~ ~.1 ~ facing entity @p feet

execute as @s[tag=summoned,scores={bosshealth=1..},tag=stage2] run particle minecraft:soul_fire_flame ~ ~2 ~ .3 .3 .3 0.1 10 force

execute as @s[tag=summoned,scores={bosshealth=..0},tag=!stage2start,tag=!stage2] at @s run stopsound @a[distance=0..30]
execute as @s[tag=summoned,scores={bosshealth=..0},tag=!stage2start,tag=!stage2] at @s run playsound minecraft:entity.player.attack.crit ambient @a[distance=0..30] ~ ~ ~ 10 0.6
execute as @s[tag=summoned,scores={bosshealth=..0},tag=!stage2start,tag=!stage2] run data merge entity @s {pose:swimming}
execute as @s[tag=summoned,scores={bosshealth=..0},tag=!stage2start,tag=!stage2] run data merge entity @s {Invulnerable:1b}
execute as @s[tag=summoned,scores={bosshealth=..0},tag=!stage2start,tag=!stage2] run tag @s add stage2start

execute as @s[tag=summoned,tag=stage2start] run scoreboard players add @s rclick 1
execute as @s[tag=summoned,tag=stage2start,scores={rclick=50..}] at @s run particle flash{color:[0.0,1.0,0.93,1]} ~ ~ ~ .3 .3 .3 0.5 1 force
execute as @s[tag=summoned,tag=stage2start,scores={rclick=0..}] at @s run weather clear
execute as @s[tag=summoned,tag=stage2start,scores={rclick=50..}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .3 .3 .3 0.1 5 force
execute as @s[tag=summoned,tag=stage2start,scores={rclick=50..51}] at @s run playsound minecraft:block.beacon.ambient ambient @a[distance=0..30] ~ ~ ~ 10 0.6
execute as @s[tag=summoned,tag=stage2start,scores={rclick=50..}] at @s run effect give @s instant_health 10 0 true
execute as @s[tag=summoned,tag=stage2start,scores={rclick=1..}] at @s if block ~ ~-1 ~ sea_lantern if block ~ ~ ~ air run tp @s ~ ~-.5 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run tag @s add stage2
execute as @s[tag=summoned,tag=stage2start,scores={rclick=148..148}] at @s run effect give @a[distance=0..50] blindness 1 10 true
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run data merge entity @s {profile:{properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMmQ0MGExODVmMjBhMjk5OWQ2ZTFhMzc4NjRhYzE0MmNiMmQ2MGMyMjJkYzY1ZTc0Nzg1NjQwNjNiOWJiYmJlMSJ9fX0="}]}}
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run time set midnight
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run playsound minecraft:block.end_portal.spawn ambient @a[distance=0..30] ~ ~ ~ 1 0.7
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:polished_blackstone replace minecraft:quartz_pillar
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:polished_blackstone_bricks replace minecraft:quartz_bricks
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:polished_blackstone_slab[type=top] replace minecraft:smooth_quartz_stairs
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:polished_blackstone_slab[type=top] replace minecraft:smooth_quartz_slab
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run data merge entity @s {pose:standing}
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run data merge entity @s {Invulnerable:0b}
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run item replace entity @s weapon.mainhand with diamond_spear
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run enchant @s minecraft:vanishing_curse
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run tp @s ~ ~1 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=120..}] at @s run weather thunder
execute as @s[tag=summoned,tag=stage2start] run effect clear @s slow_falling
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run summon lightning_bolt ~ ~-9 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run summon lightning_bolt ~ ~-9 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run summon lightning_bolt ~ ~-9 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run summon lightning_bolt ~ ~-9 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] at @s run summon lightning_bolt ~ ~-9 ~
execute as @s[tag=summoned,tag=stage2start,scores={rclick=150..}] run tag @s remove stage2start

execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @s run summon lightning_bolt ~ ~ ~

execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @e[type=breeze,tag=false] run summon lightning_bolt ~ ~ ~
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @s run summon lightning_bolt ~ 251 ~
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @e[type=breeze,tag=false] run kill @e[tag=cloud]
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @s run tp @s ~ ~.1 ~ ~ 90
execute as @s[tag=summoned,scores={bosshealth=..-50},tag=stage2,tag=!stage2start] at @s run summon minecraft:armor_stand ~ ~ ~ {Invisible:true,Invulnerable:true,ShowArms:true,DisabledSlots:4144959,Pose:{RightArm:[268f,85f,177f]},equipment:{mainhand:{id:"golden_spear",Count:1}},Tags:["spear"]}
execute as @s[tag=summoned,scores={bosshealth=..-50},tag=stage2,tag=!stage2start] at @s run kill @s
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:quartz_pillar replace minecraft:polished_blackstone
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:quartz_bricks replace minecraft:polished_blackstone_bricks
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] run execute at @e[tag=bossbattle] run fill ~-16 ~-10 ~-16 ~16 ~10 ~16 minecraft:smooth_quartz_slab[type=top] replace minecraft:polished_blackstone_slab
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @s run weather clear
execute as @s[tag=summoned,scores={bosshealth=..0},tag=stage2,tag=!stage2start] at @s run time set noon
execute as @s[tag=summoned,scores={bosshealth=1..},tag=!stage2start] at @s run weather thunder