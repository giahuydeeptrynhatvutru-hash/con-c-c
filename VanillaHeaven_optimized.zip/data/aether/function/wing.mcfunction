
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run execute at @p anchored eyes run tp @s ^ ^1 ^2 ~ ~
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run data merge entity @s {transformation:{left_rotation:[55f,-45f,90f,1f]}}
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run playsound minecraft:item.spear.lunge_1 ambient @a[distance=0..30] ~ ~ ~ 1 1.4
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tag @s add launched

execute as @s[tag=launched] at @s if block ^ ^ ^2 #aether:non_solid_air run tp @s ^ ^ ^2

execute as @s[tag=launched,tag=!stuck] at @s as @a if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run damage @e[limit=1,sort=nearest,distance=0..1.8,type=!item_display] 6 minecraft:mob_projectile by @s
execute as @s[tag=launched,tag=!stuck] at @s as @a if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run damage @e[tag=!summoned,limit=1,sort=nearest,distance=0..1.8,type=!item_display] 6 minecraft:mob_projectile by @s

execute as @s[tag=launched,tag=!stuck] at @s unless block ^ ^ ^2 #aether:non_solid_air as @a if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run execute at @s run playsound minecraft:item.trident.hit_ground ambient @s ~ ~ ~ .1 1.2
execute as @s[tag=launched,tag=!stuck] at @s unless block ^ ^ ^2 #aether:non_solid_air run playsound minecraft:item.trident.hit_ground ambient @a[distance=0..40] ~ ~ ~ 1 1.2
execute as @s[tag=launched,tag=!stuck] at @s unless block ^ ^ ^2 #aether:non_solid_air run tp @s ^ ^ ^1
execute as @s[tag=launched] at @s unless block ^ ^ ^2 #aether:non_solid_air run tag @s add stuck

execute as @s[tag=launched] at @s unless entity @a[distance=0..30] run tag @s add startretrieve

execute as @s[tag=stuck] if predicate aether:1p run tag @s add startretrieve
execute as @s[tag=startretrieve] at @s as @a if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run execute at @s run playsound minecraft:item.trident.return ambient @s ~ ~ ~ .1 1.9
execute as @s[tag=startretrieve] at @s run playsound minecraft:item.trident.return ambient @a[distance=0..40] ~ ~ ~ 1 1.9
execute as @s[tag=startretrieve] at @s run tag @s add retrieve
execute as @s[tag=startretrieve] at @s run tag @s remove launched
execute as @s[tag=startretrieve] at @s run tag @s remove startretrieve

execute as @s[tag=retrieve] at @s as @a[distance=0..40] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid facing entity @s feet run particle minecraft:end_rod ^ ^ ^1 .2 .2 .2 .001 1 force
execute as @s[tag=retrieve] at @s as @a[distance=0..40] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid facing entity @s feet run tp @e[limit=1,tag=wing,sort=nearest] ^ ^ ^1

execute as @s[tag=retrieve] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run tag @e[limit=1,tag=wing,sort=nearest] remove stuck
execute as @s[tag=retrieve] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run tag @e[limit=1,tag=wing,sort=nearest] remove launched
execute as @s[tag=retrieve] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run tag @e[limit=1,tag=wing,sort=nearest] remove shoot
execute as @s[tag=retrieve] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run data merge entity @e[limit=1,tag=wing,sort=nearest] {transformation:{left_rotation:[0f,0f,0f,1f]}}
execute as @s[tag=retrieve] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=2] run tag @e[limit=1,tag=wing,sort=nearest] add unload
execute as @s[tag=retrieve] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid unless items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] if items entity @s weapon.offhand * run tag @e[limit=1,tag=wing,sort=nearest] add unload

execute as @s[tag=retrieve,tag=!unload] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=1] run item replace entity @s weapon.offhand with snowball[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="air",custom_data={playerquil:1b}] 2

execute as @s[tag=retrieve,tag=!unload] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid unless items entity @s weapon.offhand  * run item replace entity @s weapon.offhand with snowball[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="air",custom_data={playerquil:1b}] 1

execute as @s[tag=retrieve,tag=!unload] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run playsound minecraft:item.trident.return ambient @a[distance=0..4] ~ ~ ~ 1 1.9
execute as @s[tag=retrieve,tag=!unload] at @s as @a[distance=0..3] if score @s playerid = @e[limit=1,tag=wing,sort=nearest] playerid run tag @e[limit=1,tag=wing,sort=nearest] remove retrieve

execute as @s[tag=unload] at @s run summon item ~ ~ ~ {Item:{id:feather,count:1,components:{custom_name:[{"text":"Seraph's Quil","italic":false}],lore:[[{"text":"Place in Offhand to Use","italic":false,"color":"yellow"}]],enchantments:{vanishing_curse:1},unbreakable:{},max_stack_size:2,item_model:"feather",custom_data:{2playerquil:1b}}}}
execute as @s[tag=unload] at @s run playsound minecraft:item.trident.return ambient @a[distance=0..4] ~ ~ ~ 1 .8
execute as @s[tag=unload] at @s run kill @s

