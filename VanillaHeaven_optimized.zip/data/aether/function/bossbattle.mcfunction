
execute as @s[tag=!summoned] at @s run place template aether:colosseum ~-23 ~-10 ~-24
execute as @s[tag=!summoned] at @s unless entity @e[tag=falsegod] run summon mannequin 0 251 0 {NoAI:1,CustomName:[{text:"The False God"}],hide_name:1b,hide_description:1,Invulnerable:1b,Health:100,profile:{model:wide,"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2FmN2FmZGUxMTdiZjU2MDhjMmQzMmZiZTJhNDEzMmIzNDIwYjAwY2Q4M2U2NTYwMzFlMTI1NTZhOTEzYTM2MyJ9fX0="}]},Tags:["falsegod"],attributes:[{id:scale,base:2.6}]}
execute as @s[tag=!summoned] at @s run tp @s ~ ~1 ~


execute as @s[tag=!summoned] at @s run item replace entity @e[tag=falsegod] weapon.mainhand with iron_spear

execute as @s[tag=!summoned] at @s at @e[tag=falsegod] run tp @e[tag=falsegod] ~ ~ ~ ~130 ~19


execute as @s[tag=!summoned] run fill 0 251 0 0 255 0 barrier replace air

execute as @s[tag=!summoned] at @s run tag @s add summoned

team join Aether @e[tag=falsegod]


execute as @s[scores={playerid=500000}] at @s at @e[tag=falsegod] run enchant @e[tag=falsegod,limit=1,sort=nearest] vanishing_curse


execute at @s[tag=bossbattle,scores={wings=1..181}] if block 12 253 0 air run scoreboard players set @s wings 0
execute at @s[tag=bossbattle,scores={wings=1..181}] if block -12 253 0 air run scoreboard players set @s wings 0
execute at @s[tag=bossbattle,scores={wings=1..181}] if block 0 253 12 air run scoreboard players set @s wings 0
execute at @s[tag=bossbattle,scores={wings=1..181}] if block 0 253 -12 air run scoreboard players set @s wings 0
execute at @s[tag=bossbattle] unless entity @s[scores={wings=181..}] if block 12 253 0 soul_fire if block -12 253 0 soul_fire if block 0 253 12 soul_fire if block 0 253 -12 soul_fire run function aether:bossbattlefight
execute as @s[tag=bossbattle,scores={wings=181..}] at @s run function aether:bossbattlefight