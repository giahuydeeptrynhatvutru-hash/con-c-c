
execute as @s run effect give @s slow_falling 1 1 true
execute as @s[scores={attacktime=99..}] if predicate aether:is_jumping run effect give @s minecraft:levitation 1 1 true
execute as @s[scores={attacktime=99..}] if predicate aether:is_jumping run scoreboard players remove @s attacktime 2
execute as @s[scores={attacktime=99..}] if predicate aether:is_walking run scoreboard players remove @s attacktime 1
execute as @s at @s run particle cloud ~ ~ ~ .9 0 .9 0 20 force

execute as @s if predicate aether:is_sneaking if predicate aether:is_sneaking at @s if block ~ ~-.1 ~ air run tp @s ~ ~-.1 ~

execute as @s[scores={attacktime=700..}] run title @s actionbar [{text:"☁ ☁ ☁ ☁ ☁ ☁ ☁",bold:true,color:"white"},{text:"",bold:true,color:"black"}]
execute as @s[scores={attacktime=600..699}] run title @s actionbar [{text:"☁ ☁ ☁ ☁ ☁ ☁",bold:true,color:"white"},{text:" ☁",bold:true,color:"black"}]
execute as @s[scores={attacktime=500..599}] run title @s actionbar [{text:"☁ ☁ ☁ ☁ ☁",bold:true,color:"white"},{text:" ☁ ☁",bold:true,color:"black"}]
execute as @s[scores={attacktime=400..499}] run title @s actionbar [{text:"☁ ☁ ☁ ☁",bold:true,color:"white"},{text:" ☁ ☁ ☁",bold:true,color:"black"}]
execute as @s[scores={attacktime=300..399}] run title @s actionbar [{text:"☁ ☁ ☁",bold:true,color:"white"},{text:" ☁ ☁ ☁ ☁",bold:true,color:"black"}]
execute as @s[scores={attacktime=200..299}] run title @s actionbar [{text:"☁ ☁",bold:true,color:"white"},{text:" ☁ ☁ ☁ ☁ ☁",bold:true,color:"black"}]
execute as @s[scores={attacktime=100..199}] run title @s actionbar [{text:"☁",bold:true,color:"white"},{text:" ☁ ☁ ☁ ☁ ☁ ☁",bold:true,color:"black"}]
execute as @s[scores={attacktime=0..99}] run title @s actionbar [{text:"",bold:true,color:"white"},{text:"☁ ☁ ☁ ☁ ☁ ☁ ☁",bold:true,color:"black"}]

execute as @s[scores={rclick=1..}] at @s run tag @s add weather

execute as @s[tag=weather] at @s unless predicate aether:raining run title @s title [{text:"☂",bold:false,color:"blue"}]
execute as @s[tag=weather] at @s unless predicate aether:raining run playsound minecraft:ui.button.click ambient @s ~ ~ ~
execute as @s[tag=weather] at @s unless predicate aether:raining run weather rain
execute as @s[tag=weather] at @s unless predicate aether:raining run tag @s remove weather

execute as @s[tag=weather] at @s if predicate aether:raining run title @s title [{text:"☀",bold:false,color:"yellow"}]
execute as @s[tag=weather] at @s if predicate aether:raining run playsound minecraft:ui.button.click ambient @s ~ ~ ~
execute as @s[tag=weather] at @s if predicate aether:raining run weather clear
execute as @s[tag=weather] at @s if predicate aether:raining run tag @s remove weather

execute at @s unless entity @s[tag=big] run summon minecraft:armor_stand ~ ~1 ~ {Invisible:true,Invulnerable:true,ShowArms:true,DisabledSlots:4144959,Pose:{RightArm:[268f,85f,177f]},equipment:{mainhand:{id:"golden_spear",Count:1}},Tags:["spear"]}
execute at @s unless entity @s[tag=big] run clear @s *[minecraft:custom_data={false:1b}]