
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run playsound minecraft:entity.breeze.charge ambient @a[distance=0..30] ~ ~ ~ 1 1.4
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s if entity @e[tag=stage2] run scoreboard players add @s attacktime 80
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tag @s add launched

execute as @s[tag=launched,scores={attacktime=1..}] at @s facing entity @p eyes rotated ~ ~ if block ^ ^ ^.1 #aether:non_solid_air run tp @s ^ ^ ^.1 ~ ~
execute as @s[tag=launched,scores={attacktime=90..}] at @s facing entity @p eyes rotated ~ ~ if block ^ ^ ^.05 #aether:non_solid_air run tp @s ^ ^ ^.1 ~ ~
execute as @s[tag=launched,scores={attacktime=130..}] at @s facing entity @p eyes rotated ~ ~ if block ^ ^ ^.05 #aether:non_solid_air run tp @s ^ ^ ^.05 ~ ~

execute as @s[scores={attacktime=1..80}] run particle minecraft:cloud ~ ~ ~ .2 .2 .2 0 20 force
execute as @s[scores={attacktime=50..100}] run particle minecraft:dust{color:[1,1,1],scale:2} ~ ~ ~ .2 .2 .2 0.1 20 force
execute as @s[scores={attacktime=70..160}] run particle minecraft:dust{color:[.6,.6,.6],scale:2} ~ ~ ~ .2 .2 .2 0 20 force
execute as @s[scores={attacktime=100..160}] run particle minecraft:dust{color:[.1,.1,.1],scale:2} ~ ~ ~ .2 .2 .2 0 20 force

scoreboard players add @s attacktime 1
execute as @s[scores={attacktime=160..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=160..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=160..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=160..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=160..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=160..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=160..}] at @s run kill @s