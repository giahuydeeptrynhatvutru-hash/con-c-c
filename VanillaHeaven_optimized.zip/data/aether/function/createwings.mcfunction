execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=1] run scoreboard players set @s wings 1
execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=2] run scoreboard players set @s wings 2

execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=1] run summon item_display ^ ^1 ^1 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:feather",count:1},Tags:["wing1","wing"]}

execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=2] run summon item_display ^ ^1 ^1 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:feather",count:1},Tags:["wing1","wing"]}
execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=2] run summon item_display ^ ^1 ^1 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:feather",count:1},Tags:["wing2","wing"]}

execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=1] run item replace entity @s weapon.offhand with snowball[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="air",custom_data={playerquil:1b}] 1

execute as @s at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2,count=2] run item replace entity @s weapon.offhand with snowball[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="air",custom_data={playerquil:1b}] 2

playsound minecraft:block.enchantment_table.use ambient @a[distance=0..5] ~ ~ ~ 1 1.7
particle minecraft:end_rod ~ ~1 ~ .2 .2 .2 0.2 5 force

execute as @s at @s as @e[distance=0..2,tag=wing] unless entity @s[scores={playerid=1..}] run scoreboard players operation @s playerid = @p playerid 