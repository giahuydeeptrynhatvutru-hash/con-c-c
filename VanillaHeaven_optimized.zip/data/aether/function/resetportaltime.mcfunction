stopsound @s neutral
scoreboard players set @s travelingtime 0
effect clear @s minecraft:nausea