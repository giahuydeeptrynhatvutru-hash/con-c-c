
execute as @s[tag=!summoned] at @s unless entity @e[tag=patron,type=mannequin,distance=0..2] run summon mannequin ~ ~ ~ {Invulnerable:1b,profile:{model:wide,"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTVmODhmYWQxNDJhMTcxOWEyMjYwZDZjNDY0MjViYjg3ZjUxOTA3NTU5MzE2OTcyMGY4YmJiNDVjYjY2NjY3YyJ9fX0="}]},Tags:["patron"],attributes:[{id:scale,base:1.5}]}

execute as @s[tag=!summoned] at @s run summon pig ~ ~5 ~3 {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}
execute as @s[tag=!summoned] at @s run summon pig ~-2 ~5 ~-2 {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}
execute as @s[tag=!summoned] at @s run summon pig ~2 ~5 ~-2 {Tags:["bone","create"],attributes:[{id:scale,base:0.4}]}


execute as @s[tag=!summoned] run tp @s ~ ~ ~ ~ 25
execute as @s[tag=!summoned] at @s run tp @s ~ ~ ~ facing entity @p feet
execute as @s[tag=!pain] at @s as @e[tag=patron,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run playsound minecraft:entity.copper_golem.spawn ambient @a[distance=0..15] ~ ~ ~ 1 1.2
execute as @s at @s as @e[tag=patron,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run tag @e[type=zombie,limit=1,sort=nearest,tag=patron] add pain

execute as @s[tag=!angry] run attribute @s minecraft:scale base set 0
execute as @s[tag=!summoned] run data modify entity @s NoAI set value 1
execute as @s[tag=!angry] at @s run ride @e[tag=patron,type=minecraft:mannequin,limit=1,sort=nearest] mount @s
execute as @s[tag=!angry] run execute at @s if block ~ ~-1 ~ #aether:non_solid_air run tp @s ~ ~-1 ~
execute as @s[tag=!summoned] run tag @s add summoned

execute as @s[tag=angry] run attribute @s minecraft:scale base set 1.8
execute as @s[tag=angry] run data modify entity @s NoAI set value 0

execute as @s[tag=!angry] at @s run effect give @e[tag=bone,distance=0..10] slowness 1 5 true
execute as @s[tag=!angry] at @s run execute as @e[tag=bone,distance=0..10] at @s unless block ~ ~-.1 ~ #aether:non_solid_air run tp @s ~ ~ ~ ~-5 ~ 

execute as @s[tag=!angry] at @s run execute as @e[tag=bone,distance=0..10,type=pig] at @s unless block ~ ~-.1 ~ #aether:non_solid_air if predicate aether:15p run tag @s add sing

execute as @s[scores={portalstability=3..}] at @s rotated ~ 0 run particle block{block_state:{Name:gray_terracotta}} ^.3 ^1 ^ .1 .1 .1 0 1 force
execute as @s[scores={portalstability=4..}] at @s rotated ~ 0 run particle block{block_state:{Name:light_gray_terracotta}} ^-.3 ^2 ^ .1 .1 .1 0 1 force
execute as @s[scores={portalstability=5..}] at @s rotated ~ 0 run particle block{block_state:{Name:gray_terracotta}} ^-.1 ^1.3 ^ .1 .1 .1 0 2 force
execute as @s[scores={portalstability=6..},tag=angry] at @s rotated ~ 0 run particle block{block_state:{Name:light_gray_terracotta}} ^-.1 ^2.4 ^ .1 .1 .1 0 2 force
execute as @s[scores={portalstability=7..},tag=angry] at @s rotated ~ 0 run particle block{block_state:{Name:gray_terracotta}} ^.2 ^2.4 ^ .1 .1 .1 0 2 force
execute as @s[scores={portalstability=8..}] at @s run kill @e[tag=patron,type=mannequin,limit=1,sort=nearest,distance=0..2]

execute as @s[tag=angry] at @s run tp @e[tag=patron,type=mannequin,limit=1,sort=nearest,distance=0..2] @s

execute as @s[tag=summoned] at @s unless entity @e[tag=patron,type=mannequin,distance=0..1] run summon item ~ ~1 ~ {Item:{id:netherite_ingot,count:1,components:{custom_name:[{"text":"Patron's Hear","italic":false,"color":"gray"},{"text":"t","italic":false,"color":"gray"}],lore:[[{"text":"Increases Strength and Size Upon ","italic":false,"color":"dark_green"},{"text":"C","italic":false,"color":"dark_green"},{"text":"on","italic":false,"color":"dark_green"},{"text":"s","italic":false,"color":"dark_green"},{"text":"u","italic":false,"color":"dark_green"},{"text":"m","italic":false,"color":"dark_green"},{"text":"p","italic":false,"color":"dark_green"},{"text":"tio","italic":false,"color":"dark_green"},{"text":"n","italic":false,"color":"dark_green"}]],enchantments:{power:0,unbreaking:3},food:{nutrition:10,saturation:10},consumable:{on_consume_effects:[{type:apply_effects,effects:[{id:strength,duration:999999,amplifier:1,show_particles:0b},{id:health_boost,duration:999999,amplifier:4,show_particles:0b},{id:instant_health,duration:5,amplifier:100,show_particles:0b},{id:luck,duration:999999,show_particles:0b,show_icon:0b},{id:slowness,duration:999999,amplifier:1}]}]},max_stack_size:1,item_model:"heavy_core",tooltip_display:{hidden_components:[enchantments]}}}}
execute as @s[tag=summoned] at @s unless entity @e[tag=patron,type=mannequin,distance=0..1] run kill @s

effect give @s invisibility 1 1 true
effect give @s slowness 1 0 true
effect give @s strength 1 4 true
effect give @s fire_resistance 1 1 true
effect give @s minecraft:absorption 1 4 true
attribute @s minecraft:knockback_resistance base set 1000
attribute @s minecraft:attack_knockback base set 10

data merge entity @s {Fire:0b}
execute as @s[tag=angry] at @s if predicate aether:0.001p run playsound minecraft:entity.warden.angry ambient @a[distance=0..15] ~ ~ ~ 1 0.5
execute as @s[tag=angry] at @s if predicate aether:5p run playsound minecraft:entity.iron_golem.step ambient @a[distance=0..15] ~ ~ ~ 1 0.5
team join Aether @s

execute as @s[tag=angry,tag=!reset] run effect give @s instant_damage 1 99 true
execute as @s[tag=angry] at @s unless data entity @s {Health:1024.0f} run function aether:patrondamage
execute as @s[tag=angry,tag=!reset] run scoreboard players set @s portalstability 0
execute as @s[tag=angry,tag=!reset] run tag @s add reset
