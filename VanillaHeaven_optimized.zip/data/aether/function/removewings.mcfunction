execute as @s at @s run execute as @e[tag=wing,tag=!shoot] if score @s playerid = @p playerid run kill @s


execute as @s at @s if items entity @s weapon.mainhand minecraft:snowball[minecraft:max_stack_size=2,count=1] run item replace entity @s weapon.mainhand with feather[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="feather",custom_data={playerquil:1b}] 1

execute as @s at @s if items entity @s weapon.mainhand minecraft:snowball[minecraft:max_stack_size=2,count=2] run item replace entity @s weapon.mainhand with feather[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="feather",custom_data={playerquil:1b}] 2

playsound minecraft:block.enchantment_table.use ambient @a[distance=0..5] ~ ~ ~ 1 1.4
particle minecraft:end_rod ~ ~1 ~ .2 .2 .2 0.2 5 force

execute as @s at @s if items entity @s container.* minecraft:snowball[minecraft:max_stack_size=2] run give @s feather[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="feather",custom_data={playerquil:1b}] 1
execute as @s at @s if items entity @s container.* minecraft:snowball[minecraft:max_stack_size=2] run clear @s minecraft:snowball[minecraft:max_stack_size=2] 1

execute as @s at @s if block ~ ~ ~ water if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run give @s feather[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="feather",custom_data={playerquil:1b}] 1
execute as @s at @s if block ~ ~ ~ water if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run clear @s minecraft:snowball[minecraft:max_stack_size=2] 1


execute as @s at @s if entity @s[tag=big] if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run give @s feather[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="feather",custom_data={playerquil:1b}] 1
execute as @s at @s if entity @s[tag=big] if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run clear @s minecraft:snowball[minecraft:max_stack_size=2] 1

execute as @s at @s if items entity @s armor.chest minecraft:elytra if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run give @s feather[custom_name=[{"text":"Seraph's Quil","italic":false}],lore=[[{"text":"Place in off hand to use","italic":false,"color":"yellow"}]],enchantments={vanishing_curse:1},unbreakable={},max_stack_size=2,item_model="feather",custom_data={playerquil:1b}] 1
execute as @s at @s if items entity @s armor.chest minecraft:elytra if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run clear @s minecraft:snowball[minecraft:max_stack_size=2] 1

effect clear @s minecraft:levitation
effect clear @s minecraft:slow_falling