
team join Aether @s
execute as @s[tag=!summoned] at @s run attribute @s minecraft:scale base set 2
execute as @s[tag=!summoned] at @s run enchant @s minecraft:vanishing_curse
execute as @s[tag=!summoned] at @s run tag @s add summoned

data merge entity @s {Fire:-20s}

execute as @s at @s if block ~ ~-1 ~ #aether:non_solid_air run tag @s add air
execute as @s[tag=air] at @s unless block ~ ~-1 ~ #aether:non_solid_air run playsound minecraft:item.spear.hit ambient @a[distance=0..10] ~ ~ ~ 1 1.5
execute as @s[tag=air] at @s unless block ~ ~-1 ~ #aether:non_solid_air run tag @s remove air

execute at @s positioned ~.3 ~ ~ run particle minecraft:enchant ~ ~1.7 ~ .1 1 .1 .5 3 force

execute at @s positioned ~ ~ ~ if block ~ ~ ~ fire run setblock ~ ~ ~ air

execute at @s positioned ~.3 ~ ~ run execute as @a[distance=0..0.5,tag=!big] run title @s actionbar {text:"The Spear is too Heavy!",color:"red"}
execute at @s positioned ~.3 ~ ~ run execute as @a[distance=0..0.5,tag=big] if items entity @s weapon.mainhand * run title @s actionbar {text:"You Need an Empty Hand to Lift the Spear",color:"white"}
execute at @s positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] unless items entity @s weapon.mainhand * run particle minecraft:electric_spark ~.1 ~ ~ 0 0 0 0.7 21 force
execute at @s positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] unless items entity @s weapon.mainhand * run playsound minecraft:entity.breeze.inhale ambient @a[distance=0..10] ~ ~ ~ 0.1 2
execute at @s positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] unless items entity @s weapon.mainhand * run tp @e[tag=spear,limit=1,sort=nearest] ~-.3 ~.01 ~

execute at @s positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] unless items entity @s weapon.mainhand * if block ~-.3 ~-.5 ~ #aether:non_solid_air run tag @e[tag=spear,limit=1,sort=nearest] add lifted



execute at @s[tag=lifted] positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] if block ~-.3 ~-.5 ~ #aether:non_solid_air run playsound minecraft:block.enchantment_table.use ambient @a[distance=0..5] ~ ~ ~ 1 0.7

execute at @s[tag=lifted] positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] if block ~-.3 ~-.5 ~ #aether:non_solid_air run item replace entity @s weapon.mainhand with warped_fungus_on_a_stick[custom_name=[{"text":"Lance of Lightning","bold":true,"italic":false,"color":"yellow"}],lore=[[{"text":"Right Click to Summon lightning Blast","italic":false,"color":"white"}],[{"text":"Place in off hand to float","italic":false,"color":"white"}]],rarity=epic,enchantments={unbreaking:3},attribute_modifiers=[{type:attack_damage,amount:10,slot:mainhand,operation:add_value,id:"1769905187852"},{type:gravity,amount:-0.08,slot:offhand,operation:add_value,id:"1769905187853"}],equippable={slot:mainhand},unbreakable={},item_model="golden_spear",custom_data={false:1b},tooltip_display={hidden_components:[unbreakable]}]

execute at @s[tag=lifted] positioned ~.3 ~ ~ run execute as @a[distance=0..0.7,tag=big] if block ~-.3 ~-.5 ~ #aether:non_solid_air run kill @e[tag=lifted]