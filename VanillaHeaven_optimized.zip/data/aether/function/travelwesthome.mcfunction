
execute at @s[type=!player] if dimension aether:the_aether run execute at @s in minecraft:overworld at @e[tag=portalwest,tag=!aether,limit=1,sort=nearest] run tp @s ~1 ~-3.5 ~-2
execute at @s[type=player] as @e[tag=wing,distance=0..2] if score @s playerid = @p playerid if dimension aether:the_aether run execute at @s in minecraft:overworld at @e[tag=portalwest,tag=!aether,limit=1,sort=nearest] run tp @s ~ ~-3.7 ~
execute at @s[type=player] if dimension aether:the_aether run execute at @s in minecraft:overworld at @e[tag=portalwest,tag=!aether,limit=1,sort=nearest] run tp @s ~ ~-3.7 ~-2
execute at @s run playsound minecraft:block.portal.travel ambient @s ~ ~ ~ .2 1.3
effect clear @s minecraft:nausea
scoreboard players set @s travelingtime 0