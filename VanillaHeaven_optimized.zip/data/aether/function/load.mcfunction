execute in aether:the_aether run forceload add -50 -50 50 50
scoreboard objectives add usewaterbucket minecraft.used:minecraft.water_bucket
scoreboard objectives add travelingtime dummy
scoreboard objectives add mobselector dummy
scoreboard objectives add portalstability dummy
scoreboard objectives add wings dummy
scoreboard objectives add hunger food
scoreboard objectives add playerid dummy
scoreboard objectives add health health
scoreboard objectives add bosshealth dummy
scoreboard objectives add attacktype dummy
scoreboard objectives add attacktime dummy
scoreboard objectives add carved minecraft.used:minecraft.carved_pumpkin
scoreboard objectives add snowball minecraft.used:minecraft.snowball
scoreboard objectives add rclick minecraft.used:minecraft.warped_fungus_on_a_stick
execute in aether:the_aether positioned 0 250 0 unless entity @e[tag=bossbattle] run summon marker ^ ^1 ^1 {Tags:["bossbattle"]}
team add Aether Aether
team modify Aether collisionRule pushOtherTeams
team modify Aether nametagVisibility never
bossbar add false "The False God"
bossbar set minecraft:false color blue
bossbar set minecraft:false max 400