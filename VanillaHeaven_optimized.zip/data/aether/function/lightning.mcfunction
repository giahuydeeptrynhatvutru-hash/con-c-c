
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run playsound minecraft:entity.breeze.shoot ambient @a[distance=0..30] ~ ~ ~ 1 2
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve,tag=!player] at @s run tp @s ~ ~ ~ facing entity @r[distance=0..30,limit=1,sort=random] feet
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve,tag=player] at @s at @p anchored eyes run tp @s ^ ^2 ^2.5 ~ ~
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tag @s add launched

execute as @s[tag=launched,scores={attacktime=1..}] at @s if block ^ ^ ^.1 #aether:non_solid_air run tp @s ^ ^ ^.7 ~ ~
execute as @s[tag=launched,scores={attacktime=1..},tag=player] at @s if block ^ ^ ^.1 #aether:non_solid_air run tp @s ^ ^ ^.3 ~ ~
execute as @s[scores={attacktime=1..80},tag=!player] at @s run particle minecraft:electric_spark ~ ~ ~ .1 .1 .1 .1 4 force
execute as @s[scores={attacktime=1..80},tag=!player] at @s run particle minecraft:enchanted_hit ~ ~ ~ .1 .1 .1 0 20 force

execute as @s[scores={attacktime=1..80},tag=player] at @s run particle minecraft:dust{color:[1.0,0.97,0.0],scale:2} ^ ^ ^-.5 .01 .01 .01 .1 1 force
execute as @s[scores={attacktime=1..80},tag=player] at @s run particle minecraft:dust{color:[1.0,0.97,0.0],scale:2} ~ ~ ~ .01 .01 .01 .1 1 force
execute as @s[scores={attacktime=1..80},tag=player] at @s run particle minecraft:wax_on ~ ~ ~ .1 .1 .1 .1 3 force


scoreboard players add @s attacktime 1

execute as @s[scores={attacktime=1..}] at @s unless block ^ ^ ^.1 #aether:non_solid_air run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=1..}] at @s if entity @e[distance=0.1..2,tag=!falsegod,tag=!lightning,tag=!cloud,type=!marker] run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=1..}] at @s unless block ^ ^ ^.1 #aether:non_solid_air run kill @s
execute as @s[scores={attacktime=1..}] at @s if entity @e[distance=0.1..2,tag=!falsegod,tag=!lightning,tag=!cloud,type=!marker] run kill @s
execute as @s[scores={attacktime=80..}] at @s run summon lightning_bolt ~ ~ ~
execute as @s[scores={attacktime=80..}] at @s run kill @s