execute as @s at @s if dimension minecraft:overworld run tag @s add overworld
# [FIX] Thoát sớm nếu overworld - không xử lý thêm
execute as @s[tag=overworld] run return 0

execute as @s[tag=bone] at @s unless entity @s[scores={mobselector=1..}] run scoreboard players set @s mobselector 1
execute as @s[tag=!bone] at @s if dimension aether:the_aether unless entity @s[scores={mobselector=1..}] run execute store result score @s mobselector run random value 1..10
execute as @s at @s if entity @s[scores={mobselector=1..7}] run tag @s add bone
execute as @s at @s if entity @s[scores={mobselector=8}] run tag @s add patron
execute as @s at @s if entity @s[scores={mobselector=9}] run tag @s add breeze
execute as @s at @s if entity @s[scores={mobselector=10}] run tag @s add seraph

execute as @s[tag=create] at @s run fill ~ ~ ~ ~ ~1 ~ air replace bone_block
execute as @s[tag=create] at @s run fill ~ ~ ~ ~ ~1 ~ air replace carved_pumpkin

effect give @s minecraft:resistance 3 9 true

data merge entity @s[scores={mobselector=1..10}] {Silent:1b}

team join Aether @s[scores={mobselector=1..10}]

execute as @s[tag=bone] run attribute @s minecraft:scale base set 0.4

execute as @s[scores={mobselector=1..}] run data merge entity @s {DeathLootTable:""}

execute as @s[tag=patron] at @s run summon zombie ~ ~ ~ {DeathLootTable:"",CustomName:[{text:Patron}],Health:100,PersistenceRequired:1b,Silent:1b,Tags:["patron"],equipment:{mainhand:{id:air},offhand:{id:air}},attributes:[{id:max_health,base:1000000f}]}

execute as @s[tag=seraph] at @s run summon mannequin ~ ~ ~ {NoAI:1,CustomName:[{text:Seraph}],hide_name:1b,hide_description:1,Invulnerable:0b,Health:100,profile:{model:slim,"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNGY3YjY1YTk5NzQwN2M5YmQ2NWM4ODllNTQzODI4ODAyYjVlYzEwYzFiMGY1YmZhMTljN2NhYjMwNjBmMzNjNiJ9fX0="}]},Tags:["seraph"],attributes:[{id:scale,base:1.2}]}

execute as @s[tag=seraph] run kill @s
execute as @s[tag=patron] run kill @s
execute as @s[tag=breeze] at @s run summon breeze ~ ~ ~
execute as @s[tag=breeze] run kill @s
