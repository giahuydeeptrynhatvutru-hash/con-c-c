
execute at @s[type=!player] if dimension minecraft:overworld run execute in aether:the_aether run tp @s ~ 200 ~1
execute at @s[type=player] as @e[tag=wing,distance=0..2] if score @s playerid = @p playerid if dimension minecraft:overworld run execute in aether:the_aether run tp @s ~ 200 ~
execute at @s[type=player] if dimension minecraft:overworld run execute in aether:the_aether run tp @s ~ 200 ~
execute at @s run playsound minecraft:block.portal.travel ambient @s ~ ~ ~ .2 1.3
effect clear @s minecraft:nausea
scoreboard players set @s travelingtime 0
