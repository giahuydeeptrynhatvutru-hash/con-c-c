execute at @s run particle flash{color:[0.58,0.93,0.96,0]} ~ ~1.5 ~ 1 2 1 1 3

execute at @s run playsound minecraft:block.glass.break block @a[distance=0..10] ~ ~ ~ 1 0.4
execute at @s run playsound minecraft:block.glass.break block @a[distance=0..10] ~ ~ ~ 1 1

execute at @s as @e[type=block_display,limit=1,sort=nearest,distance=0..7] at @s run kill @e[distance=0..0.1,type=block_display]

kill @s