
execute as @s[scores={wings=2,snowball=1..}] at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=1] run tag @e[tag=wing,tag=!shoot,limit=1,sort=nearest,distance=0..3] add shoot
execute as @s[scores={wings=2,snowball=1..}] at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=1] run kill @e[type=snowball,limit=1,sort=nearest]
execute as @s[scores={wings=2,snowball=1..}] at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=1] run scoreboard players set @s snowball 0

execute as @s[scores={wings=1,snowball=1..}] at @s run tag @e[tag=wing,tag=!shoot,limit=1,sort=nearest,distance=0..3] add shoot
execute as @s[scores={wings=1,snowball=1..}] at @s run kill @e[type=snowball,limit=1,sort=nearest]
execute as @s[scores={wings=1,snowball=1..}] at @s run scoreboard players set @s snowball 0

execute as @s at @s unless items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run scoreboard players set @s wings 0
execute as @s at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=1] run scoreboard players set @s wings 1
execute as @s at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2,count=2] run scoreboard players set @s wings 2

execute as @s[scores={wings=1}] at @s unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing1,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^ ^1.3 ^-.2 ~ ~
execute as @s[scores={wings=1}] at @s if predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing1,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^ ^1.3 ^-.2 ~ ~30
execute as @s[scores={wings=1}] at @s if predicate aether:is_sprinting if predicate aether:is_walking unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing1,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^ ^1.3 ^-.1 ~ ~

execute as @s[scores={wings=1}] at @s unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing2,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^ ^1.3 ^-.2 ~ ~
execute as @s[scores={wings=1}] at @s if predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing2,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^ ^1.3 ^-.2 ~ ~30
execute as @s[scores={wings=1}] at @s if predicate aether:is_sprinting if predicate aether:is_walking unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing2,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^ ^1.3 ^-.1 ~ ~

execute as @s[scores={wings=2..},tag=!flap] at @s unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing1,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^.5 ^1.7 ^-.5 ~135 ~
execute as @s[scores={wings=2..}] at @s if predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing1,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^.5 ^1.3 ^-.1 ~180 ~-30
execute as @s[scores={wings=2..}] at @s if predicate aether:is_jumping unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing1,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^.1 ^1.7 ^-.5 ~120 ~

execute as @s[scores={wings=2..},tag=!flap] at @s unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing2,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^-.5 ^1.7 ^-.5 ~45 ~
execute as @s[scores={wings=2..}] at @s if predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing2,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^-.5 ^1.3 ^-.1 ~ ~30
execute as @s[scores={wings=2..}] at @s if predicate aether:is_jumping unless predicate aether:is_sneaking at @s as @e[type=minecraft:item_display,tag=wing2,tag=!shoot] if score @s playerid = @p playerid run execute at @p anchored eyes rotated ~ 0 run tp @s ^-.1 ^1.7 ^-.5 ~70 ~

# [FIX] data modify Motion mỗi tick rất nặng -> chỉ chạy khi đang bay (wings=2..) và throttle mỗi 2 tick
execute as @s[scores={wings=2..},tag=!wing_sync_skip] at @s as @e[type=minecraft:item_display,tag=wing,tag=!shoot] if score @s playerid = @p playerid run data modify entity @s Motion set from entity @p Motion
execute as @a[scores={wings=2..},tag=wing_sync_skip] run tag @s remove wing_sync_skip
execute as @a[scores={wings=2..},tag=!wing_sync_skip] run tag @s add wing_sync_skip

execute as @s at @s if predicate aether:is_sneaking run tp @e[tag=wing,tag=!shoot,tag=!shoot,limit=1,sort=random,distance=0..2] @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..4,limit=1,sort=nearest]

execute as @s at @s if predicate aether:is_sneaking as @e[tag=wing,tag=!shoot,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run playsound minecraft:item.spear.attack voice @a[distance=0..20] ~ ~ ~ 1 1.5

execute as @s at @s if predicate aether:is_sneaking as @e[tag=wing,tag=!shoot,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run particle minecraft:sweep_attack ~ ~.2 ~ 0.1 0.1 0.1 0 10
execute as @s at @s if predicate aether:is_sneaking as @e[tag=wing,tag=!shoot,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run data modify entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1,limit=1,sort=nearest] Motion set value 0
execute as @s at @s if predicate aether:is_sneaking as @e[tag=wing,tag=!shoot,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run tag @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1,limit=1,sort=nearest] add stopped

effect give @s minecraft:slow_falling 1 1 true

execute as @s[tag=flap] unless predicate aether:is_jumping run tag @s remove flap
execute as @s[scores={wings=2..,hunger=6..},tag=!flap] at @s unless predicate aether:is_sneaking unless block ~ ~-.5 ~ #aether:non_solid_air unless predicate aether:is_sneaking run effect give @s jump_boost 1 3 true
execute as @s[scores={wings=2..hunger=6..},tag=!flap] at @s unless predicate aether:is_sneaking if block ~ ~-.5 ~ #aether:non_solid_air if predicate aether:is_jumping run effect give @s levitation 1 3 true
execute as @s[scores={wings=2..hunger=5..},tag=!flap] at @s unless predicate aether:is_sneaking if block ~ ~-.5 ~ #aether:non_solid_air if predicate aether:is_jumping run effect give @s hunger 1 10 true
execute as @s[scores={wings=2..},tag=!flap] at @s unless predicate aether:is_sneaking if block ~ ~-.5 ~ #aether:non_solid_air if predicate aether:is_jumping run playsound minecraft:entity.ender_dragon.flap ambient @a[distance=0..13] ~ ~ ~ 1 1.7
execute as @s[scores={wings=2..},tag=!flap] at @s unless predicate aether:is_sneaking if block ~ ~-.5 ~ #aether:non_solid_air if predicate aether:is_jumping run tag @s add flap

