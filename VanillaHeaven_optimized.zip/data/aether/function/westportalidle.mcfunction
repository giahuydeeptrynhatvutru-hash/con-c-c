particle dust{color:[0,.7,.9],scale:1} ~ ~-2 ~-2 .1 1 .5 1 2

execute positioned ~ ~-3 ~-1.5 run execute as @a[distance=0..1.5] at @s if block ~ ~-1 ~ minecraft:glowstone if entity @s[scores={travelingtime=5}] run playsound minecraft:block.portal.trigger neutral @s ~ ~ ~ 0.1 0
execute positioned ~ ~-3 ~-1.5 run execute as @a[distance=0..1.5] at @s if block ~ ~-1 ~ minecraft:glowstone run effect give @s minecraft:nausea 5 11 true

execute positioned ~ ~-3 ~-1.5 run execute as @a[distance=0..1.5] at @s if block ~ ~-1 ~ minecraft:glowstone run scoreboard players add @s travelingtime 1
execute positioned ~ ~-3 ~-1.5 run execute as @a[distance=0..1.5,gamemode=creative] at @s if block ~ ~-1 ~ minecraft:glowstone run scoreboard players add @s travelingtime 1

execute positioned ~ ~-3 ~-1.5 run execute as @a[distance=0..1.5] at @s if dimension aether:the_aether if block ~ ~-1 ~ minecraft:glowstone if entity @s[scores={travelingtime=100..}] run execute at @s run function aether:travelwesthome
execute positioned ~ ~-3 ~-1.5 run execute as @a[distance=0..1.5] at @s if dimension minecraft:overworld if block ~ ~-1 ~ minecraft:glowstone if entity @s[scores={travelingtime=100..}] run execute at @s run function aether:travelwestaether

execute positioned ~ ~-3 ~-1.5 run execute as @e[type=!player,type=!item_display,type=!block_display,type=!marker,distance=0..1.5] at @s if dimension aether:the_aether if block ~ ~-1 ~ minecraft:glowstone run execute at @s run function aether:travelwesthome
execute positioned ~ ~-3 ~-1.5 run execute as @e[type=!player,type=!item_display,type=!block_display,type=!marker,distance=0..1.5] at @s if dimension minecraft:overworld if block ~ ~-1 ~ minecraft:glowstone run execute at @s run function aether:travelwestaether

scoreboard players set @s portalstability 0

execute at @s positioned ~-2 ~-3 ~ run fill ~-1 ~ ~ ~ ~3 ~ air replace water


execute at @s if dimension aether:the_aether positioned ~ ~-4 ~-3 if block ~ ~3 ~2 glowstone if block ~ ~3 ~-1 glowstone if block ~ ~-1 ~2 glowstone if block ~ ~-1 ~-1 glowstone if block ~ ~-1 ~ glowstone if block ~ ~-1 ~1 glowstone if block ~ ~3 ~ glowstone if block ~ ~3 ~1 glowstone if block ~ ~2 ~-1 glowstone if block ~ ~1 ~-1 glowstone if block ~ ~ ~-1 glowstone if block ~ ~2 ~2 glowstone if block ~ ~1 ~2 glowstone if block ~ ~ ~2 glowstone if block ~ ~ ~1 air if block ~ ~ ~ air if block ~ ~1 ~1 air if block ~ ~1 ~ air if block ~ ~2 ~1 air if block ~ ~2 ~ air run scoreboard players set @s portalstability 1

execute at @s if dimension minecraft:overworld positioned ~ ~-3 ~-3 if block ~ ~3 ~2 glowstone if block ~ ~3 ~-1 glowstone if block ~ ~-1 ~2 glowstone if block ~ ~-1 ~-1 glowstone if block ~ ~-1 ~ glowstone if block ~ ~-1 ~1 glowstone if block ~ ~3 ~ glowstone if block ~ ~3 ~1 glowstone if block ~ ~2 ~-1 glowstone if block ~ ~1 ~-1 glowstone if block ~ ~ ~-1 glowstone if block ~ ~2 ~2 glowstone if block ~ ~1 ~2 glowstone if block ~ ~ ~2 glowstone if block ~ ~ ~1 air if block ~ ~ ~ air if block ~ ~1 ~1 air if block ~ ~1 ~ air if block ~ ~2 ~1 air if block ~ ~2 ~ air run scoreboard players set @s portalstability 1

execute as @s[tag=earth] if dimension minecraft:overworld if entity @s[scores={portalstability=0}] run execute in aether:the_aether positioned ~ 200 ~ run summon minecraft:marker ~ ~ ~ {Invisible:1b,Invulnerable:1b,Tags:["destroyportal"]}

execute as @s[tag=aether] if entity @s[scores={portalstability=0}] run execute at @s in minecraft:overworld positioned ~ ~-100 ~ as @e[type=block_display,tag=portalwest,tag=earth,limit=1,sort=nearest] at @s run summon minecraft:marker ~ ~ ~ {Invisible:1b,Invulnerable:1b,Tags:["destroyportal"]}

execute at @s if entity @s[scores={portalstability=0}] run particle flash{color:[0.58,0.93,0.96,0]} ~ ~1.5 ~ 1 2 1 1 3

execute at @s if entity @s[scores={portalstability=0}] run playsound minecraft:block.glass.break block @a[distance=0..10] ~ ~ ~ 1 0.4
execute at @s if entity @s[scores={portalstability=0}] run playsound minecraft:block.glass.break block @a[distance=0..10] ~ ~ ~ 1 1

execute as @s if entity @s[scores={portalstability=0}] run kill @e[type=block_display,distance=0..0.1]