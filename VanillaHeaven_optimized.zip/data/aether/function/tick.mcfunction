execute as @a[scores={usewaterbucket=1..}] at @s unless entity @e[type=block_display,distance=0..50] if dimension minecraft:overworld run function aether:usewaterbucket
execute as @a[scores={carved=1..}] at @s unless entity @e[tag=bone,distance=0..5] run function aether:usecarved
execute as @a[scores={travelingtime=1..}] at @s unless block ~ ~-1 ~ glowstone run function aether:resetportaltime
execute as @e[tag=portalnorth] at @s run function aether:northportalidle
execute as @e[tag=portalwest] at @s run function aether:westportalidle
execute as @e[tag=destroyportal] at @s run function aether:destroyportal

# [FIX] Thêm dimension filter để không duyệt pig/rabbit ngoài aether
execute as @e[type=pig,tag=!overworld,tag=!patron,tag=!bone,tag=!seraph,tag=!breeze] in aether:the_aether at @s run function aether:pigsetup
execute as @e[type=rabbit,tag=!overworld] in aether:the_aether at @s run function aether:rabbitsetup
execute as @e[type=pig,tag=bone,tag=create] at @s run function aether:pigsetup

execute as @e[type=pig,tag=bone] at @s run function aether:bonegolem
execute as @e[tag=quilcontrol] at @s run function aether:quilcontrol
execute as @e[tag=cloud] at @s run function aether:cloud
execute as @e[tag=heal] at @s run function aether:heal
execute as @e[tag=spear] at @s run function aether:spear
execute as @e[tag=lightning] at @s run function aether:lightning
execute as @e[type=zombie,tag=patron] at @s run function aether:patron
execute as @e[type=mannequin,tag=seraph] at @s run function aether:seraph
execute as @e[type=mannequin,tag=falsegod,tag=awake] at @s run function aether:falsegod
execute as @e[type=item_display,tag=quil,tag=shoot] at @s run function aether:quil
execute as @e[type=item_display,tag=wing,tag=shoot] at @s run function aether:wing
execute as @e[type=mannequin,tag=bone] at @s unless entity @e[tag=bone,type=pig,distance=0] run kill @s
kill @e[type=minecraft:zombified_piglin,tag=bone]
execute as @a unless entity @s[scores={playerid=1..}] run execute store result score @s playerid run random value 1..9999999
execute as @a at @s if dimension aether:the_aether if predicate aether:lowery run execute in minecraft:overworld run tp @s ~ 500 ~

execute as @e[tag=quil,tag=!shoot] at @s unless entity @e[tag=seraph,distance=0..5] run kill @s
execute as @e[tag=quil,tag=shoot] at @s unless entity @e[tag=seraph,distance=0..40] run kill @s
execute as @e[tag=wing,tag=shoot] at @s unless entity @a[distance=0..80] run kill @s
execute as @e[tag=wing,tag=!shoot] at @s unless entity @a[distance=0..5] run kill @s
execute at @e[tag=bossbattle,limit=1,sort=nearest] unless entity @e[tag=falsegod,limit=1,sort=nearest,tag=awake] run bossbar set minecraft:false players @a[tag=boof]

execute as @e[tag=bossbattle] at @s run scoreboard players add @s playerid 1
execute as @e[tag=bossbattle] at @s as @e[tag=bossbattle,limit=1,sort=furthest,distance=0.5..] if score @n playerid > @s playerid run kill @s

execute as @e[tag=bossbattle] at @s run function aether:bossbattle

execute as @a at @s if items entity @s container.* minecraft:snowball[minecraft:max_stack_size=2] unless items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] run function aether:removewings
execute as @a at @s if items entity @s weapon.mainhand minecraft:snowball[minecraft:max_stack_size=2] run function aether:removewings
execute as @a at @s if items entity @s weapon.offhand minecraft:feather[minecraft:max_stack_size=2] unless block ~ ~ ~ water unless items entity @s armor.chest minecraft:elytra run function aether:createwings
execute as @a at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] unless block ~ ~ ~ water unless items entity @s armor.chest minecraft:elytra run function aether:wearingwings
execute as @a[scores={wings=1}] at @s unless items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] unless block ~ ~ ~ water unless items entity @s armor.chest minecraft:elytra run function aether:wearingwings

execute as @a at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] if items entity @s armor.chest minecraft:elytra run function aether:removewings
execute as @a at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] if block ~ ~ ~ water run function aether:removewings
execute as @a at @s if items entity @s weapon.offhand minecraft:snowball[minecraft:max_stack_size=2] if entity @s[tag=big] run function aether:removewings

kill @e[tag=stopped,type=!player,type=!#minecraft:arrows,type=!minecraft:trident]

execute as @a if items entity @s weapon.mainhand *[minecraft:custom_data={false:1b}] run function aether:lightning_spear
execute as @a if items entity @s weapon.offhand *[minecraft:custom_data={false:1b}] run function aether:lightning_spear_offhand
execute as @a unless entity @s[scores={wings=1..}] run scoreboard players set @s snowball 0

# [FIX] Thay NBT selector luck -> dùng tag thay vì nbt={active_effects:[...]} mỗi tick
execute as @a[tag=!big,tag=luck] run attribute @s scale base set 1.5
execute as @a[tag=!big,tag=luck] at @s run playsound minecraft:block.conduit.activate ambient @a[distance=0..5] ~ ~ ~ 1 0
execute as @a[tag=!big,tag=luck] at @s run particle minecraft:firework ~ ~1 ~ .3 .3 .3 .1 100 force
execute as @a[tag=!big,tag=luck] run tag @s add big

execute as @a[tag=big,tag=!luck] run attribute @s scale base set 1
execute as @a[tag=big,tag=!luck] run tag @s remove big

# [FIX] detect luck effect để set tag (1 lần check NBT thay vì 4 lần)
execute as @a[tag=!luck] if entity @s[nbt={active_effects:[{"id":"minecraft:luck"}]}] run tag @s add luck
execute as @a[tag=luck] unless entity @s[nbt={active_effects:[{"id":"minecraft:luck"}]}] run tag @s remove luck

# [FIX] Thêm distance limit cho item NBT check
execute as @e[type=item,distance=..64,nbt={Item:{components:{"minecraft:custom_data":{false:1b}}}}] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invisible:true,Invulnerable:true,ShowArms:true,DisabledSlots:4144959,Pose:{RightArm:[268f,85f,177f]},equipment:{mainhand:{id:"golden_spear",Count:1}},Tags:["spear"]}
execute as @e[type=item,distance=..64,nbt={Item:{components:{"minecraft:custom_data":{false:1b}}}}] at @s run kill @s
scoreboard players set @a rclick 0
scoreboard players set @a usewaterbucket 0
scoreboard players set @a carved 0
