
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tp @s ^ ^ ^1 facing entity @a[distance=0..18,limit=1,sort=nearest] feet
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run data merge entity @s {transformation:{left_rotation:[45f,-45f,45f,1f]}}
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run playsound minecraft:item.spear.lunge_1 ambient @a[distance=0..30] ~ ~ ~ 1 1.4
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tag @s add launched

execute as @s[tag=launched] at @s if block ^ ^ ^2 #aether:non_solid_air run tp @s ^ ^ ^2

execute as @s[tag=launched,tag=!stuck] at @s run damage @e[tag=!seraph,team=!Aether,limit=1,sort=nearest,distance=0..1.8,type=!item_display] 8 minecraft:mob_projectile by @e[tag=seraph,limit=1,sort=nearest]

execute as @s[tag=launched,tag=!stuck] at @s unless block ^ ^ ^2 #aether:non_solid_air run playsound minecraft:item.trident.hit_ground ambient @a[distance=0..20] ~ ~ ~ 1 1.2
execute as @s[tag=launched,tag=!stuck] at @s unless block ^ ^ ^2 #aether:non_solid_air run tp @s ^ ^ ^1
execute as @s[tag=launched] at @s unless block ^ ^ ^2 #aether:non_solid_air run tag @s add stuck

execute as @s[tag=launched] at @s unless entity @e[tag=seraph,distance=0..25] run tag @s add startretrieve

execute as @s[tag=stuck] if predicate aether:0.01p run tag @s add startretrieve
execute as @s[tag=startretrieve] at @s run playsound minecraft:item.trident.return ambient @a[distance=0..20] ~ ~ ~ 1 1.9
execute as @s[tag=startretrieve] at @s run tag @s add retrieve
execute as @s[tag=startretrieve] at @s run tag @s remove launched
execute as @s[tag=startretrieve] at @s run tag @s remove startretrieve

execute as @s[tag=retrieve] at @s facing entity @e[tag=seraph,limit=1,sort=nearest] feet run particle minecraft:end_rod ^ ^ ^1 .2 .2 .2 .001 1 force
execute as @s[tag=retrieve] at @s facing entity @e[tag=seraph,limit=1,sort=nearest] feet run tp @s ^ ^ ^1

execute as @s[tag=retrieve] at @s if entity @e[tag=seraph,distance=0..3] run tag @s remove stuck
execute as @s[tag=retrieve] at @s if entity @e[tag=seraph,distance=0..3] run tag @s remove shoot

