scoreboard players add @s wings 1

execute as @s[scores={wings=1}] at @s run playsound minecraft:entity.wither.spawn ambient @a[distance=0..30] ~ ~ ~ 11 0.3
execute as @s[scores={wings=1}] at @s run playsound minecraft:entity.wither.spawn ambient @a[distance=0..30] ~ ~ ~ 11 2
execute as @s[scores={wings=1}] at @s run weather thunder

execute as @s[scores={wings=41}] at @s run playsound minecraft:entity.lightning_bolt.thunder ambient @a[distance=0..30] ~ ~ ~ 11 0

execute at @s[scores={wings=61}] run execute at @e[tag=falsegod] run playsound minecraft:entity.wither.break_block ambient @a[distance=0..15] ~ ~ ~ 1 0.8
execute at @s[scores={wings=61}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:calcite}} ~ ~3 ~ 0.5 1.5 0.5 0.05 200 force

execute at @s[scores={wings=101}] run playsound minecraft:entity.warden.heartbeat ambient @a[distance=0..15] ~ ~ ~ 1 0
execute at @s[scores={wings=161}] run playsound minecraft:entity.warden.heartbeat ambient @a[distance=0..15] ~ ~ ~ 1 0

execute at @s[scores={wings=121}] run execute at @e[tag=falsegod] run playsound minecraft:entity.wither.break_block ambient @a[distance=0..15] ~ ~ ~ 1 0.6
execute at @s[scores={wings=121}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:stone}} ~ ~2 ~ 0.5 1.5 0.5 0.05 200 force

execute at @s[scores={wings=181}] run execute at @e[tag=falsegod] run playsound minecraft:entity.wither.break_block ambient @a[distance=0..15] ~ ~ ~ 1 0
execute at @s[scores={wings=171}] run execute at @e[tag=falsegod] run playsound minecraft:entity.warden.emerge ambient @a[distance=0..15] ~ ~ ~ 1 2
execute at @s[scores={wings=181}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:stone}} ~ ~2 ~ 0.5 1.5 0.5 0.05 200 force
execute at @s[scores={wings=181}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:calcite}} ~ ~2 ~ 0.5 1.5 0.5 0.05 200 force
execute at @s[scores={wings=181}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:bedrock}} ~ ~2 ~ 0.5 1.5 0.5 0.05 200 force
execute at @s[scores={wings=181}] run execute at @e[tag=falsegod] run fill ~-1 ~-1 ~-1 ~1 ~10 ~1 air replace barrier
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod,limit=1] run tag @s add awake
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run attribute @s minecraft:max_health base set 500
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run attribute @s minecraft:knockback_resistance base set 10000
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run effect give @s instant_health 5 200 true
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run data merge entity @s {Invulnerable:0b}

execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run data merge entity @s {profile:{properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTg2NmVmNzFmYjc2MWUwN2UxMDg0MTQzY2I4Njk2MDY3NGIxOGYwODgxYTExOTBjZjE1YThlMjFkOWRkOTU1NiJ9fX0="}]}}
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run item replace entity @s weapon.mainhand with golden_spear
execute at @s[scores={wings=181}] run execute as @e[tag=falsegod] run enchant @s minecraft:vanishing_curse


execute at @s[scores={wings=61..185}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:calcite}} ~ ~2 ~ 0.3 1 0.3 0.05 11 force
execute at @s[scores={wings=121..185}] run execute at @e[tag=falsegod] run particle block{block_state:{Name:stone}} ~ ~2 ~ 0.3 1 0.3 0.05 11 force
execute at @s[scores={wings=1..185}] run execute positioned 12 253 0 run particle soul_fire_flame ~ ~1 ~ -1 -0.3 0 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned -12 253 0 run particle soul_fire_flame ~ ~1 ~ 1 -0.3 0 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned 0 253 12 run particle soul_fire_flame ~ ~1 ~ 0 -0.3 -1 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned 0 253 -12 run particle soul_fire_flame ~ ~1 ~ 0 -0.3 1 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned 12 253 0 run particle copper_fire_flame ~ ~1 ~ -1 -0.3 0 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned -12 253 0 run particle copper_fire_flame ~ ~1 ~ 1 -0.3 0 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned 0 253 12 run particle copper_fire_flame ~ ~1 ~ 0 -0.3 -1 0.6 0 force
execute at @s[scores={wings=1..185}] run execute positioned 0 253 -12 run particle copper_fire_flame ~ ~1 ~ 0 -0.3 1 0.6 0 force

execute at @s[scores={wings=185..190}] run execute positioned 12 253 0 if block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~ ~
execute at @s[scores={wings=185..190}] run execute positioned -12 253 0 if block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~ ~
execute at @s[scores={wings=185..190}] run execute positioned 0 253 12 if block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~ ~
execute at @s[scores={wings=185..190}] run execute positioned 0 253 -12 if block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~ ~

execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~ ~ soul_fire run particle soul_fire_flame ~ ~1 ~ 0 1 0 0.6 0 force
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~ ~ soul_fire run particle soul_fire_flame ~ ~1 ~ 0 1 0 0.6 0 force
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~ ~ soul_fire run particle soul_fire_flame ~ ~1 ~ 0 1 0 0.6 0 force
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~ ~ soul_fire run particle soul_fire_flame ~ ~1 ~ 0 1 0 0.6 0 force
execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~ ~ soul_fire run particle copper_fire_flame ~ ~1 ~ 0 1 0 1 0 force
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~ ~ soul_fire run particle copper_fire_flame ~ ~1 ~ 0 1 0 1 0 force
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~ ~ soul_fire run particle copper_fire_flame ~ ~1 ~ 0 1 0 1 0 force
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~ ~ soul_fire run particle copper_fire_flame ~ ~1 ~ 0 1 0 1 0 force

execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~ ~ soul_fire run particle entity_effect{color:[0.0,0.98,1.0,1.0]} ~ ~1 ~ 0.2 1 0.2 1 10 force
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~ ~ soul_fire run particle entity_effect{color:[0.0,0.98,1.0,1.0]} ~ ~1 ~ 0.2 1 0.2 1 10 force
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~ ~ soul_fire run particle entity_effect{color:[0.0,0.98,1.0,1.0]} ~ ~1 ~ 0.2 1 0.2 1 10 force
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~ ~ soul_fire run particle entity_effect{color:[0.0,0.98,1.0,1.0]} ~ ~1 ~ 0.2 1 0.2 1 10 force



execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run damage @e[tag=falsegod,limit=1,sort=nearest] 50 minecraft:explosion
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run damage @e[tag=falsegod,limit=1,sort=nearest] 50 minecraft:explosion
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run damage @e[tag=falsegod,limit=1,sort=nearest] 50 minecraft:explosion
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run damage @e[tag=falsegod,limit=1,sort=nearest] 50 minecraft:explosion
execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon lightning_bolt ~ ~-2 ~
execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon tnt ~ ~ ~ {fuse:0}
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon tnt ~ ~ ~ {fuse:0}
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon tnt ~ ~ ~ {fuse:0}
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run summon tnt ~ ~ ~ {fuse:0}
execute at @s[scores={wings=185..}] run execute positioned 12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run setblock ~ ~-1 ~ air
execute at @s[scores={wings=185..}] run execute positioned -12 253 0 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run setblock ~ ~-1 ~ air
execute at @s[scores={wings=185..}] run execute positioned 0 253 12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run setblock ~ ~-1 ~ air
execute at @s[scores={wings=185..}] run execute positioned 0 253 -12 if block ~ ~-1 ~ soul_soil unless block ~ ~ ~ soul_fire run setblock ~ ~-1 ~ air