
execute as @s[tag=!summoned] at @s rotated ~ 0 run summon marker ^ ^1 ^1 {Tags:["quilcontrol"]}
execute as @s[tag=!summoned] at @s rotated ~ 0 run summon item_display ^ ^1 ^1 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:feather",count:1},Tags:["quil1","quil"]}
execute as @s[tag=!summoned] at @s rotated ~ 0 run summon item_display ^-1 ^1 ^-1 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:feather",count:1},Tags:["quil2","quil"]}
execute as @s[tag=!summoned] at @s rotated ~ 0 run summon item_display ^1 ^1 ^-1 {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:feather",count:1},Tags:["quil3","quil"]}

execute as @s[tag=summoned] at @s as @e[tag=quil,tag=!shoot,distance=0..4] run data merge entity @s {transformation:{left_rotation:[0f,0f,0f,1f]}}
execute as @s[tag=summoned] at @s as @e[tag=quil,tag=!shoot,distance=0..4] run tag @s remove retrieve
team join Aether @s
execute as @s[tag=!summoned] at @s run tp @s ~ ~ ~ facing entity @p feet
execute as @s[tag=!pain] at @s as @e[tag=seraph,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run playsound minecraft:entity.copper_golem.spawn ambient @a[distance=0..15] ~ ~ ~ 1 1.2
execute as @s at @s as @e[tag=seraph,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run tag @e[type=zombie,limit=1,sort=nearest,tag=seraph] add pain

execute as @s[tag=summoned] at @s run tp @e[tag=quilcontrol,limit=1,sort=nearest,distance=0..10] ~.1 ~ ~
execute as @s[tag=summoned] at @s as @e[tag=quilcontrol,limit=1,sort=nearest,distance=0..10] at @s run tp @s ^ ^ ^ ~20 0
execute as @s[tag=summoned] at @s run particle minecraft:end_rod ~ ~.9 ~ .3 .3 .3 0.1 1 force

execute as @s[tag=summoned] at @s if entity @e[tag=quil,distance=0..2,tag=!shoot] unless block ~ ~-7 ~ #aether:non_solid_air if block ~ ~2.2 ~ #aether:non_solid_air if block ~ ~.1 ~ #aether:non_solid_air run tp @s ~ ~.1 ~ ~ ~
execute as @s[tag=summoned,tag=!angry] run tp @s ~ ~ ~ ~-1 ~
execute as @s[tag=summoned,tag=angry] if entity @e[tag=quil,distance=0..3,tag=!shoot] if entity @a[distance=0..15] run tp @s ~ ~ ~ facing entity @p
execute as @s[tag=summoned,tag=angry] if entity @e[tag=quil,distance=0..3,tag=!shoot] unless entity @a[distance=0..15] if entity @a[distance=15..60] if block ^ ^ ^1 #aether:non_solid_air run tp @s ^ ^ ^1 facing entity @p
execute as @s[tag=summoned,tag=angry] if entity @e[tag=quil,distance=0..3,tag=!shoot] if entity @a[distance=0..7] if block ^ ^ ^-1 #aether:non_solid_air run tp @s ^ ^ ^-1 facing entity @p
execute as @s[tag=summoned] if entity @e[tag=quil,distance=0..3,tag=!shoot] unless block ~ ~-7 ~ #aether:non_solid_air if block ~ ~.1 ~ #aether:non_solid_air run tp @s ~ ~.1 ~ ~ ~
execute as @s[tag=!summoned] run tag @s add summoned
execute as @s[tag=summoned] at @s as @e[tag=quilcontrol] at @e[tag=!shoot,tag=quil1,limit=1,sort=nearest,distance=0..30] unless entity @e[distance=0..2,tag=stopped] run execute at @s run tp @e[tag=!shoot,tag=quil1,limit=1,sort=nearest,distance=0..30] ^.5 ^1.9 ^ ~180 0
execute as @s[tag=summoned] at @s as @e[tag=quilcontrol] at @e[tag=!shoot,tag=quil2,limit=1,sort=nearest,distance=0..30] unless entity @e[distance=0..2,tag=stopped] run execute at @s run tp @e[tag=!shoot,tag=quil2,limit=1,sort=nearest,distance=0..30] ^-.2 ^1.8 ^.5 ~290 0
execute as @s[tag=summoned] at @s as @e[tag=quilcontrol] at @e[tag=!shoot,tag=quil3,limit=1,sort=nearest,distance=0..30] unless entity @e[distance=0..2,tag=stopped] run execute at @s run tp @e[tag=!shoot,tag=quil3,limit=1,sort=nearest,distance=0..30] ^-.2 ^1.7 ^-.5 ~50 0

data merge entity @s {Fire:0b}
execute as @s at @s if predicate aether:0.001p run playsound minecraft:entity.baby_nautilus.ambient ambient @a[distance=0..15] ~ ~ ~ 1 0.2
execute as @s at @s if predicate aether:0.001p run playsound minecraft:entity.baby_nautilus.ambient ambient @a[distance=0..15] ~ ~ ~ 1 0.3
team join Aether @s

execute as @s[tag=summoned] at @s unless block ~ ~-.1 ~ #aether:non_solid_air run tag @e[tag=quil,distance=0..20,limit=1,sort=nearest] add startretrieve

execute as @s[tag=summoned,tag=!pain] at @s unless entity @s[nbt={HurtTime:0s}] run particle block{block_state:{Name:redstone_block}} ~ ~1 ~ .5 1 .5 0 120 force
execute as @s[tag=summoned,tag=!pain] at @s unless entity @s[nbt={HurtTime:0s}] run playsound minecraft:entity.enderman.hurt ambient @a[distance=0..15] ~ ~ ~ 10 1.7
execute as @s[tag=summoned,tag=!pain] at @s unless entity @s[nbt={HurtTime:0s}] run tag @s add angry
execute as @s[tag=summoned,tag=!pain] at @s unless entity @s[nbt={HurtTime:0s}] run tag @s add pain

execute as @s[tag=pain] at @s if entity @s[nbt={HurtTime:0s}] run tag @s remove pain

execute as @s[tag=angry] at @s if predicate aether:0.01p run tag @e[tag=!shoot,limit=1,sort=random,distance=0..4,tag=quil] add shoot
execute as @s[tag=angry] at @s if predicate aether:0.01p run tag @e[tag=!shoot,limit=1,sort=random,distance=0..4,tag=quil] add shoot
execute as @s[tag=angry] at @s if predicate aether:0.01p run tag @e[tag=!shoot,limit=1,sort=random,distance=0..4,tag=quil] add shoot

execute as @s at @s run tp @e[tag=quil,tag=!shoot,limit=1,sort=random,distance=0..2] @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..4,limit=1,sort=nearest]

execute as @s at @s as @e[tag=quil,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run playsound minecraft:item.spear.attack voice @a[distance=0..20] ~ ~ ~ 1 1.5

execute as @s at @s as @e[tag=quil,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run particle minecraft:sweep_attack ~ ~.2 ~ 0.1 0.1 0.1 0 10
execute as @s at @s as @e[tag=quil,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run data modify entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1,limit=1,sort=nearest] Motion set value 0

execute as @s at @s as @e[tag=quil,tag=!shoot,distance=0..4] at @s run execute if entity @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] run tag @e[type=#minecraft:impact_projectiles,tag=!stopped,distance=0..1] add stopped

execute as @s[tag=!angry] at @s if entity @e[type=#minecraft:impact_projectiles,tag=stopped,distance=0..4] run playsound minecraft:entity.sniffer.death ambient @a[distance=0..25] ~ ~ ~ 1 2
execute as @s[tag=!angry] at @s if entity @e[type=#minecraft:impact_projectiles,tag=stopped,distance=0..4] run playsound minecraft:entity.sniffer.death ambient @a[distance=0..25] ~ ~ ~ 1 1
execute as @s[tag=!angry] at @s if entity @e[type=#minecraft:impact_projectiles,tag=stopped,distance=0..4] run playsound minecraft:entity.sniffer.death ambient @a[distance=0..25] ~ ~ ~ 1 0
execute as @s[tag=!angry] at @s if entity @e[type=#minecraft:impact_projectiles,tag=stopped,distance=0..4] run playsound minecraft:entity.evoker.prepare_summon ambient @a[distance=0..25] ~ ~ ~ 1 2
execute as @s[tag=!angry] at @s if entity @e[type=#minecraft:impact_projectiles,tag=stopped,distance=0..4] run tag @s add angry

effect give @s minecraft:slow_falling infinite 1 true
effect give @s minecraft:resistance infinite 2 true