execute as @s[tag=!summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..2] run summon mannequin ~ ~ ~ {profile:{model:slim,"properties":[{"name":"textures","value":"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNmZiZTg0YTM5NGQ0OTE4NDQ1MTYyMTQ0ODQ0M2E5YmM2MzY2NTZkODFmNzI0YzlkN2RhNDUzNjdhMzIyZWRmMCJ9fX0="}]},Tags:["bone"],attributes:[{id:scale,base:0.6}]}

execute as @s[tag=pain] at @s as @e[tag=bone,type=mannequin,distance=0..1,limit=1,sort=nearest] if entity @s[nbt={HurtTime:0s}] run tag @e[type=pig,limit=1,sort=nearest,tag=bone] remove pain

execute as @s at @s as @e[tag=bone,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run damage @e[tag=bone,type=pig,limit=1,sort=nearest] 1 minecraft:arrow by @p

execute as @s[tag=!pain] at @s as @e[tag=bone,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run playsound minecraft:entity.copper_golem.spawn ambient @a[distance=0..15] ~ ~ ~ 1 1.2
execute as @s at @s as @e[tag=bone,type=mannequin,distance=0..1,limit=1,sort=nearest] unless entity @s[nbt={HurtTime:0s}] run tag @e[type=pig,limit=1,sort=nearest,tag=bone] add pain

execute as @s[tag=!summoned] run tag @s add summoned
# [FIX] growplants throttle - chỉ chạy khi bonegolem đứng trên farmland (giữ nguyên, đã có 1p)
execute as @s at @s if block ~ ~-.5 ~ minecraft:farmland if predicate aether:1p run function aether:growplants

execute as @s at @s run tp @e[tag=bone,type=mannequin,limit=1,sort=nearest,distance=0..2] @s
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] run summon item ~ ~1 ~ {Item:{id:"minecraft:bone_meal",Count:1}}
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] if predicate aether:15p run summon item ~ ~.3 ~.1 {Item:{id:"minecraft:orange_tulip",Count:1}}
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] if predicate aether:15p run summon item ~.2 ~.3 ~.1 {Item:{id:"minecraft:pink_tulip",Count:1}}
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] run playsound minecraft:entity.skeleton.death ambient @a[distance=0..5] ~ ~ ~ 1 1.6
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] run execute at @e[tag=patron,type=zombie,distance=0..10] run playsound minecraft:entity.warden.roar ambient @a[distance=0..15] ~ ~ ~ 1 0.4
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] run tag @e[tag=patron,type=zombie,distance=0..10] add angry
execute as @s[tag=summoned] at @s unless entity @e[tag=bone,type=mannequin,distance=0..1] run kill @s

# [FIX] data modify InLove mỗi tick rất nặng -> chỉ set khi vừa spawned (tag=!inlove_reset)
execute as @s[tag=!inlove_reset] run data modify entity @s InLove set value 0
execute as @s[tag=!inlove_reset] run tag @s add inlove_reset
effect give @s invisibility 1 1 true
effect give @s resistance 1 11 true

execute at @s if predicate aether:0.001p if block ~ ~-1 ~ minecraft:grass_block if block ~ ~ ~ air run setblock ~ ~ ~ minecraft:pink_tulip
execute at @s if predicate aether:0.001p if block ~ ~-1 ~ minecraft:grass_block if block ~ ~ ~ air run setblock ~ ~ ~ minecraft:orange_tulip
execute at @s if predicate aether:0.01p if block ~ ~-1 ~ minecraft:grass_block if block ~ ~ ~ air run setblock ~ ~ ~ minecraft:short_grass

execute if predicate aether:0.001p run playsound minecraft:entity.copper_golem.spin ambient @a[distance=0..5] ~ ~ ~ 1 1

execute as @e[tag=sing] at @s run tp @s ~ ~.3 ~
execute as @e[tag=sing] at @s run particle minecraft:note ~ ~.5 ~ .2 .2 .2 1 1
execute as @e[tag=sing] at @s if predicate aether:35p run playsound minecraft:block.note_block.xylophone ambient @a[distance=0..13] ~ ~ ~ 1 1
execute as @e[tag=sing] at @s if predicate aether:35p run playsound minecraft:block.note_block.xylophone ambient @a[distance=0..13] ~ ~ ~ 1 1.16
execute as @e[tag=sing] at @s if predicate aether:35p run playsound minecraft:block.note_block.xylophone ambient @a[distance=0..13] ~ ~ ~ 1 1.56
execute as @e[tag=sing] at @s if predicate aether:5p run playsound minecraft:block.note_block.xylophone ambient @a[distance=0..13] ~ ~ ~ 1 2
execute as @e[tag=sing] at @s run tag @s remove sing
