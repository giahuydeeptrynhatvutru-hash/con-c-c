execute at @s run playsound minecraft:item.mace.smash_ground_heavy ambient @a[distance=0..15] ~ ~ ~ 1 .9
execute at @s run playsound minecraft:entity.warden.hurt ambient @a[distance=0..15] ~ ~ ~ 1 0.2
execute at @s run particle block{block_state:{Name:light_gray_terracotta}} ~ ~1 ~ .5 1 .5 0 120 force

execute at @s run effect give @s slowness 1 10 true
execute at @s run tp @s ~ ~ ~ ~ ~90

execute at @s run effect give @s instant_damage 1 230 true

scoreboard players add @s portalstability 1


