
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run playsound minecraft:block.end_portal_frame.fill ambient @a[distance=0..20] ~ ~ ~ 1 1.8
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tp @s ~ ~ ~ facing entity @e[tag=falsegod,limit=1,sort=nearest] feet
execute as @s[tag=!launched,tag=!stuck,tag=!retrieve] at @s run tag @s add launched

execute as @s[tag=launched] at @s run tp @s ^ ^ ^.3 ~ ~

execute at @s run particle entity_effect{color:[0.0,0.98,1.0,1.0]} ~ ~ ~ .2 .2 .2 0 11 force

execute at @s if entity @e[distance=0.1..1] run effect give @e[distance=0.1..2,type=!marker] instant_health 1 0 true
execute at @s if entity @e[distance=0.1..1] run playsound minecraft:block.end_portal_frame.fill ambient @a[distance=0..20] ~ ~ ~ 1 1.9
execute at @s if entity @e[distance=0.1..1] run particle flash{color:[0.0,0.98,1.0,1.0]} ~ ~ ~ .2 .2 .2 0 1 force
execute at @s if entity @e[distance=0.1..1] run kill @s